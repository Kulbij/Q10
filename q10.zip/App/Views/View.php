<?php namespace App\views;

use App\Controllers\Functions;

class View
{
	public function run($isAjax = false)
	{
		$data = [];

		if ($isAjax) {
			$user = new Functions;
			$data = $user->run($_POST);

			return ['main' => require  __DIR__ . '/ajax.php'];
		} else {
			require  __DIR__ . '/index.php';
		}
	}
}