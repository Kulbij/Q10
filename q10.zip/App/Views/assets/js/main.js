function getAjax() {
    var loadind = "<p>Loading...</p>";
    $('#ajax_put_block').html(loadind);

    var ajax_url = "/index.php?ajax=on";
    var store_url = $('form input[name="store_url"]').val();

    if (store_url != "") {
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: {url: store_url},
        }).done(function(data) {
            $('#ajax_put_block').html(data);

        });
    }
}