<?php 

require __DIR__.'/../Autoloader.php';


use App\Controllers\Functions;


// if ($_POST['web'] == 'run') {
	$user = new Functions;
// echo "string";
// }
