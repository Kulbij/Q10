<?php namespace Config;

$config = [

    'url' => 'http://www.qoo10.sg/shop/surfersparadise?search_mode=basic',
    
];

define('BASE_URL', '../' . __DIR__);